_underscore_, *asterisk*, _one two_, *three four*, _a_, *b*

**strong** and *em* and **strong** and *em*

_line
line
line_

this_is_not_an_emphasis

an empty emphasis __ ** is not an emphasis

*mixed **double and* single asterisk** spans